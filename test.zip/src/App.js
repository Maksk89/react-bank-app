import React from 'react';
import Dashboard from './pages/Dashboard/Dashboard';

const App = () => {
  return (
    <>
      <Dashboard/>
    </>
  );
};

export default App;
